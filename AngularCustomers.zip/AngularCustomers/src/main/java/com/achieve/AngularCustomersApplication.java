package com.achieve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularCustomersApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularCustomersApplication.class, args);
	}
}
