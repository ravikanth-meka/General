Please have a look at http://www.amasik.com/angularjs-sample-project/
http://localhost:8091/partials/users/login.html